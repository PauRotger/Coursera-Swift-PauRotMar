//: Playground - AssignmentWeek2

import UIKit


                    //JUEGO DE MEMORIA

var rangoVal =  0...100 //Rango valores de 0 a 100. Incluyendo ambos números

print("Inicializando Juego de Memoria, espere porfavor...")
print("\n")
print("**********")

for val in rangoVal{ //Inicio bucle for en dicho rango
    
    //Divible entre 5??
    if val % 5 == 0{
        print("El número \(val) es divisible entre 5,  Bingo!!!")
    }
    //Es par o impar??
    if val % 2 == 0{
        print("El número \(val) es Par!!!")
    }else if val % 2 != 0 {
        print("El número \(val) es Impar!!!")
    }
    //Suponemos que el 30 y el 40 se incluyen en el rango.
    if val >= 30 && val  <= 40{
        print("El número \(val) se encuentra en el rango [30,40], Viva Swift!!!")
    }
    
}

print("**********")
print("\n")

print("Juego terminado. Gracias por participar!")



